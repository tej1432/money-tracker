// //for select_icon
// import 'package:eva_icons_flutter/eva_icons_flutter.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_boxicons/flutter_boxicons.dart';
// import 'package:font_awesome_flutter/font_awesome_flutter.dart';
// import 'package:icofont_flutter/icofont_flutter.dart';
// import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
// import 'package:outline_material_icons/outline_material_icons.dart';
//
// import 'category_item.dart';
// import 'constants.dart';
//
//
// // [
// // categoryItem(Icons.business_center_rounded, ''),
// // categoryItem(IcoFontIcons.moneyBag, ''),
// // categoryItem(IcoFontIcons.searchJob, ''),
// // categoryItem(IcoFontIcons.gift, ''),
// // categoryItem(MdiIcons.cashPlus, ''),
// // categoryItem(MdiIcons.food, ''),
// // categoryItem(MdiIcons.foodDrumstick, ''),
// // categoryItem(Icons.local_bar, ''),
// // categoryItem(Icons.add_shopping_cart, ''),
// // categoryItem(OMIcons.commute, ''),
// // categoryItem(Icons.local_gas_station, ''),
// // categoryItem(Icons.local_parking, ''),
// // categoryItem(IcoFontIcons.toolsBag, ''),
// // categoryItem(Icons.local_taxi_outlined, ''),
// // categoryItem(IcoFontIcons.businessman, ''),
// // categoryItem(IcoFontIcons.education, ''),
// // categoryItem(Icons.business, ''),
// // categoryItem(IcoFontIcons.bagAlt, ''),
// // categoryItem(IcoFontIcons.shoppingCart, ''),
// // categoryItem(Boxicons.bxs_t_shirt, ''),
// // categoryItem(Boxicons.bxs_binoculars, ''),
// // categoryItem(Boxicons.bxs_devices, ''),
// // categoryItem(Icons.add_photo_alternate_outlined, ''),
// // categoryItem(Icons.movie_filter, ''),
// // categoryItem(IcoFontIcons.gameController, ''),
// // categoryItem(Icons.library_music, ''),
// // categoryItem(Icons.airplanemode_active, ''),
// // categoryItem(MdiIcons.homeHeart, ''),
// // categoryItem(MdiIcons.homeCurrencyUsd, ''),
// // categoryItem(MdiIcons.tableChair, ''),
// // categoryItem(MdiIcons.autoFix, ''),
// // categoryItem(MdiIcons.dogService, ''),
// // categoryItem(Icons.emoji_transportation, ''),
// // categoryItem(IcoFontIcons.lightBulb, ''),
// // categoryItem(IcoFontIcons.globe, ''),
// // categoryItem(IcoFontIcons.stockMobile, ''),
// // categoryItem(IcoFontIcons.waterDrop, ''),
// // categoryItem(FontAwesomeIcons.handHoldingMedical, ''),
// // categoryItem(MdiIcons.soccer, ''),
// // categoryItem(MdiIcons.fileDocumentMultipleOutline, ''),
// // categoryItem(MdiIcons.doctor, ''),
// // categoryItem(MdiIcons.medicalBag, ''),
// // categoryItem(Boxicons.bxs_donate_heart, ''),
// // categoryItem(IcoFontIcons.gift, ''),
// // categoryItem(IcoFontIcons.love, ''),
// // categoryItem(IcoFontIcons.worried, ''),
// // categoryItem(IcoFontIcons.usersSocial, ''),
// // categoryItem(Icons.child_care, ''),
// // categoryItem(MdiIcons.cashCheck, ''),
// // categoryItem(MdiIcons.babyBottle, ''),
// // categoryItem(MdiIcons.humanBabyChangingTable, ''),
// // categoryItem(MdiIcons.bookCheck, ''),
// // categoryItem(EvaIcons.options, ''),
// // ];
