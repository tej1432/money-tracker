// import 'package:flutter/cupertino.dart';
//
// import '../app_pages/home.dart';
// import 'welcome_page.dart';
//
// class Wrapper extends StatelessWidget {
//   final UserUid userUid;
//   const Wrapper(this.userUid);
//   @override
//   Widget build(BuildContext context) {
//     print('${userUid.uid}');
//     if (userUid.uid == '') {
//       return WelcomePage();
//     } else {
//       return Home();
//     }
//   }
// }
